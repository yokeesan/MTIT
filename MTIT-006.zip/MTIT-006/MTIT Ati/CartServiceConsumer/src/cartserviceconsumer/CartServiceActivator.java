package cartserviceconsumer;

import cartserviceproducer.CartServiceProducer;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

public class CartServiceActivator implements BundleActivator {

	ServiceReference serviceReference;

	public void start(BundleContext context) throws Exception {
		
		System.out.println("");
		serviceReference = context.getServiceReference(CartServiceProducer.class.getName());
		CartServiceProducer servicePublish = (CartServiceProducer) context.getService(serviceReference);
		System.out.println(servicePublish.publishCartService());
		servicePublish.addItemToCart();
	}

	public void stop(BundleContext context) throws Exception {
		System.out.println("end");
		context.ungetService(serviceReference);
	}

}
