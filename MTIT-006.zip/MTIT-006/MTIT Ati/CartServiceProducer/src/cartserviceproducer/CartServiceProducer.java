package cartserviceproducer;

public interface CartServiceProducer {
	
	public String publishCartService();
	
	public String addItemToCart();
}
