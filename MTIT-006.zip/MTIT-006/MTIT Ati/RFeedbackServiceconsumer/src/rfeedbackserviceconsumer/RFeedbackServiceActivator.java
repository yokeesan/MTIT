package rfeedbackserviceconsumer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import rfeedbackserviceproducer.RFeedbackServiceProducer;

public class RFeedbackServiceActivator implements BundleActivator {

	ServiceReference serviceReference;

	public void start(BundleContext context) throws Exception {

		System.out.println("");
		serviceReference = context.getServiceReference(RFeedbackServiceProducer.class.getName());
		RFeedbackServiceProducer servicePublish = (RFeedbackServiceProducer) context.getService(serviceReference);
		servicePublish.getCustomerFeedback();
		
	}

	public void stop(BundleContext context) throws Exception {

		System.out.println("end");
		context.ungetService(serviceReference);
		
	}

}
