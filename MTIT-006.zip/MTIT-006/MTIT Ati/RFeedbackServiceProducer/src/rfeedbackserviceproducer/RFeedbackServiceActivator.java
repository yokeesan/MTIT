package rfeedbackserviceproducer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

import rfeedbackserviceproducer.RFeedbackServiceProducer;
import rfeedbackserviceproducer.RFeedbackServiceProducerImpl;

public class RFeedbackServiceActivator implements BundleActivator {
ServiceRegistration FeedbackServiceRegistration;
	
	public void start(BundleContext context) throws Exception {
		System.out.println("Feedback Section");
		RFeedbackServiceProducer publisherService = new RFeedbackServiceProducerImpl();
		FeedbackServiceRegistration = context.registerService(
				RFeedbackServiceProducer.class.getName(), publisherService, null);
	}

	public void stop(BundleContext context) throws Exception {

		System.out.println("Feedback functionality stop");
		FeedbackServiceRegistration.unregister();
		
	}

}
