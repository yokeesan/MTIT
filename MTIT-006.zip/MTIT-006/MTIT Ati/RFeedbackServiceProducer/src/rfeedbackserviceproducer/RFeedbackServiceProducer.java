package rfeedbackserviceproducer;

public interface RFeedbackServiceProducer {
	public String getCustomerFeedback();
}
