package paymentserviceproducer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class PaymentServiceActivator1 implements BundleActivator {
	
	ServiceRegistration publishServiceRegistration;

	public void start(BundleContext context) throws Exception {
		
		System.out.println("Payment Section");
		PaymentServiceProducer publisherService = new PaymentServiceProduceImpl();
		publishServiceRegistration = context.registerService(
				PaymentServiceProducer.class.getName(), publisherService, null);
		
		
	}

	public void stop(BundleContext context) throws Exception {
		System.out.println("Payment functionality stop");
		publishServiceRegistration.unregister();
	}

}
