package paymentserviceproducer;

public interface PaymentServiceProducer {
	public String publishCartService();
	
	public String addPaymentService();

}
