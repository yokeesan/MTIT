package osgi_deliveryproducer;

public interface DeliveryServiceProducer {
	
	public String getCustomerDeliveryDetails();

}
