package osgi_deliveryproducer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class DeliveryServiceActivator implements BundleActivator {

	ServiceRegistration publishServiceRegistration;

	

	public void start(BundleContext context) throws Exception {
		System.out.println("Delivery Section start");
		DeliveryServiceProducer publisherService = new DeliveryServiceProducerImpl();
		publishServiceRegistration = context.registerService(
				DeliveryServiceProducer.class.getName(), publisherService, null);
	}

	public void stop(BundleContext context) throws Exception {
		System.out.println("Delivery Section stop");
		publishServiceRegistration.unregister();
	}

}
