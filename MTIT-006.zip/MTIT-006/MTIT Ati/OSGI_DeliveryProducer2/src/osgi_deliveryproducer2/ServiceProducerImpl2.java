package osgi_deliveryproducer2;
import java.util.Scanner;

public class ServiceProducerImpl2 implements DeliveryServiceProducer2 {

	Scanner scanner= new Scanner(System.in);
		@Override
	public String publishService() {
		// TODO Auto-generated method stub
		String town="";
		int km_1;
		int charge, dis=0;
		
		System.out.println("");
		System.out.println("............Your Delivery Charge.......");
		System.out.println("");
		System.out.println("Enter your town Distance to your location:");
		town = scanner.nextLine();
		dis= scanner.nextInt();
		
			switch(town) {
		case "ampara":
			km_1=1000;
			charge = km_1*dis;
			System.out.println("Your delivery Charge is"+ town +"town is" +charge+ "/=rupees");
			break;
			
		case "colombo":
			km_1=500;
			charge = km_1*dis;
			System.out.println("Your delivery Charge is"+ town +"town is" +charge+ "/=rupees");
			break;
			
		case "kandy":
			km_1=80;
			charge = km_1*dis;
			System.out.println("Your delivery Charge is"+ town +"town is" +charge+ "/=rupees");
			break;
			
		case "jaffna":
			km_1=800;
			charge = km_1*dis;
			System.out.println("Your delivery Charge is"+ town + "town is" + charge + "/=rupees");
			break;
			
		default :
			System.out.println("You Enterd Invalid Town Pleace Try Again");
		}
		
		System.out.println("");
		System.out.println("............................................");
		
		
		return"Thank you";
	}
	
}
