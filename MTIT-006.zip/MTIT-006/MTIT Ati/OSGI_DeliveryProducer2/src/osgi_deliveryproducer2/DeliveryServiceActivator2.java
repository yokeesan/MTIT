 package osgi_deliveryproducer2;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class DeliveryServiceActivator2 implements BundleActivator {

	ServiceRegistration publishServiceRegistration;

	public void start(BundleContext context) throws Exception {
		System.out.println("Producer2 Start");
		DeliveryServiceProducer2 producerService = new ServiceProducerImpl2();
		
		publishServiceRegistration = context.registerService(DeliveryServiceProducer2.class.getName(),producerService,null);
	}

	public void stop(BundleContext bundleContext) throws Exception {
		System.out.println("Producer2 Stop");
		publishServiceRegistration.unregister();
	}

}
