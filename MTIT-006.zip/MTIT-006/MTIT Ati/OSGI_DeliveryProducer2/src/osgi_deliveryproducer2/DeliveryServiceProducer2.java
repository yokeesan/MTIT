package osgi_deliveryproducer2;

public interface DeliveryServiceProducer2 {
	public String publishService();

}
