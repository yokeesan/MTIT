package productserviceproducer;

public interface ProductServiceProducer {
	public String showProducts();

}
