package osgi_deliveryconsumer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import osgi_deliveryproducer.DeliveryServiceProducer;
import osgi_deliveryproducer2.DeliveryServiceProducer2;

public class DeliveryServiceActivator implements BundleActivator {

	ServiceReference serviceReference;

	public void start(BundleContext context) throws Exception {
		
		System.out.println("");
		System.out.println("Start Consumer Service 1\n");
		serviceReference = context.getServiceReference(DeliveryServiceProducer.class.getName());
		DeliveryServiceProducer servicePublish = (DeliveryServiceProducer) context.getService(serviceReference);
		servicePublish.getCustomerDeliveryDetails();
		
		
		System.out.println("Start Consumer Service 2\n");
		serviceReference = context.getServiceReference(DeliveryServiceProducer2.class.getName());
		DeliveryServiceProducer2 servicePublish2 = (DeliveryServiceProducer2)context.getService(serviceReference);
		System.out.println(servicePublish2.publishService());
		
	}

	public void stop(BundleContext context) throws Exception {
		
		System.out.println("end");
		context.ungetService(serviceReference);
		
		
	}

}
