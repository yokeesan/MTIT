package paymentserviceconsumer;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import paymentserviceproducer.PaymentServiceProducer;

public class PaymentServiceActivator1 implements BundleActivator {

	ServiceReference serviceReference;

	public void start(BundleContext context) throws Exception {
		
		System.out.println("");
		serviceReference = context.getServiceReference(PaymentServiceProducer.class.getName());
		PaymentServiceProducer servicePublish = (PaymentServiceProducer) context.getService(serviceReference);
		System.out.println(servicePublish.publishCartService());
		servicePublish.addPaymentService();
		
		
	}

	public void stop(BundleContext context) throws Exception {
		System.out.println("end");
		context.ungetService(serviceReference);
		
	}

}
